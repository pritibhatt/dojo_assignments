
import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-author-new',
  templateUrl: './author-new.component',
  styleUrls: ['./author-new.component.css']
})
export class AddNewComponent implements OnInit {
  newProduct: any;
  constructor(private _httpService: HttpService) { }

  ngOnInit() {
    this.newProduct = { name: "", qty: "", price: "" }

  }
  onSubmit(newProduct){
    
    // Code to send off the form data (this.newTask) to the Service
    let observable = this._httpService.addProduct(this.newProduct);
      observable.subscribe(data => {
      console.log("Got our authors!", data);
    // ...
    // Reset this.newTask to a new, clean object.
    this.newProduct = {name: "", qty: "", price: ""};
    })
  }
}
