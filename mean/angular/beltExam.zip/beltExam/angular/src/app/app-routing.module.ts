import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//component
import { AppComponent } from './app.component';
import { AddNewComponent } from './add-new/add-new.component';
import { ProductsHomeComponent } from './products-home/products-home.component';
import { EditComponent } from './edit/edit.component';


const routes: Routes = [
  { path: 'new', component: AddNewComponent},
  { path: '', component: ProductsHomeComponent},
  { path: 'edit/:id', component: EditComponent},
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
